测试需要考虑到各种情况：
     有无， super interfaece, 各种type, 各种flag, 各种接口。 gson.

     next will support map for parceable.


    javapoet 生成builder
    https://github.com/josketres/builderator/blob/master/src/test/java/com/josketres/builderator/BuilderatorTest.java


javax.lang.module Elements 等之类的封装。参考项目: juzu
