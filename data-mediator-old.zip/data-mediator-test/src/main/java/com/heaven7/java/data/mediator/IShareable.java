package com.heaven7.java.data.mediator;

public interface IShareable {

	void clearShare();
}
