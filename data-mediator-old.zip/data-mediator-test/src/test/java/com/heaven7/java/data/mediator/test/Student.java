package com.heaven7.java.data.mediator.test;

//@Fields
public interface Student {

}
