package com.heaven7.data.mediator.demo;

/**
 * Created by Administrator on 2017/8/29 0029.
 */

public interface TestInterface2 extends StudentBind {
}
