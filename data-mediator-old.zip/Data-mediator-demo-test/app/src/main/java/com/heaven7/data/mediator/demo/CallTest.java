package com.heaven7.data.mediator.demo;

/**
 * Created by heaven7 on 2017/9/10.
 */

public class CallTest {

    public void test1(){
       // StudentBindModule sbm = new StudentBindModule_Impl();
    }
}
